#Funcion Sumar
def sumar(a,b):
	return "El Resultado de la suma es igual a: ", a+b