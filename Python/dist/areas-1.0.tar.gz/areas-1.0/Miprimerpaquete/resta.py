#Funcion Restar
def restar(a,b):
	return "El Resultado de la resta es igual a: ", a-b