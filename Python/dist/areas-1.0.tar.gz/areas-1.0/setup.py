from setuptools import setup

setup(

	name="areas",
	version="1.0",
	description="Calcula Area y Perimetro de un Rectangulo",
	author="Alberto Graterol",
	author_email="algcmusic18@gmail.com",
	#Aqué se coloca el paque que está en la raiz y luego el paquete con el subpaquete
	packages=["Miprimerpaquete","Miprimerpaquete.Areas"]
	)

'''
consola de windows
shift + click derecho en la carpeta de paquete
navegamos con "cd"

para crear paquetes distribuibles escribimos:
-python setup.py sdist-

revisamos las carpetas.
luego navegamos a la carpeta dist en la terminal
-pip3 install nombredelarchivocomprimido en la carpeta dist con la extension
-pip3 install Miprimerpaquete.trg.gz
enter
y listo
luego desinstalamos
pip3 uninstall nombredelpaquete sin la extension
pip3 uninstall paquete

'''